﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Shopping.DataAccess.Data;
using Shopping.Models;
using System.Data;
using System.Diagnostics;
using static Shopping.Models.ApplicationUser;

namespace ShoppingWeb.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
      //  private readonly SignInManager<IdentityUser> _signInManager;
        private readonly ApplicationDbContext _db;


        public HomeController(ILogger<HomeController> logger, UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager,ApplicationDbContext db)
        {
            _logger = logger;
            _userManager = userManager;
            _roleManager = roleManager;
            _db = db;
         //   _signInManager = signInManager;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(LoginVM obj)
        {
            try
            {
                var data = await _userManager.FindByEmailAsync(obj.Email);
                var role = await _userManager.GetRolesAsync(data);
                ViewBag.Role = role;
            
                if (data != null && await _userManager.CheckPasswordAsync(data, obj.Password))
                 {
                        return RedirectToAction("Dashboard");
                  } 
                    
                return View();
            }
            catch(Exception ex)
            {
                throw ex;
            }
           
        }

        public async Task<IActionResult> Privacy()
        {
            ApplicationUser applicationUser = new ApplicationUser()
            {
                UserName = "Parshav",
                Email = "Parshav@gmail.com",
              //  PasswordHash = "Par123",
                Name = "Parshav",
                EmailConfirmed = false,
                PhoneNumber = "9876543210",
                State = "Gujarat",
                LockoutEnabled = false,
                PostalCode = "380001",
                SecurityStamp = "7jfehfefnkwndjgrkvjedfnef",
                ConcurrencyStamp = "ythrhtg-ewewbfhbt-sgrwgrgrg-6524-mkrgmrk",
                City = "Ahmedabad",
                loginStatus = LoginStatus.Approved
            };
            await _userManager.CreateAsync(applicationUser,applicationUser.PasswordHash="Parshav123@");

            if (_roleManager.RoleExistsAsync("SuperAdmin").GetAwaiter().GetResult())
            {
                IdentityResult result = await _userManager.AddToRoleAsync(applicationUser, "SuperAdmin");
            }

            return View();
        }


        public async Task<IActionResult> Dashboard()
        {          

            switch (ViewBag.Role)
            {
                case "SuperAdmin":
                    var data = "Admin/dealer";
                     return RedirectToAction("Dashboard", data);
                case "Admin":
                    var dataset = "dealer";
                    return RedirectToAction("Dashboard", dataset);

                case "Dealer":
                    //var dataset = "product";

                    return RedirectToAction("Dealer");

            }

            IEnumerable<DashboardVM> applicationUsers;
            applicationUsers = (from AU in _db.applicationUsers
                                join UR in _db.UserRoles
                                on AU.Id equals UR.UserId
                                join RL in _db.Roles
                                on UR.RoleId equals RL.Id where RL.Name == "SuperAdmin"
                                select (new DashboardVM
                                    {
                                      UserName = AU.UserName,
                                    Email = AU.Email,
                                    State = AU.State,
                                    Role = RL.Name,
                                    Id= RL.Id,
                                    Status = AU.loginStatus.ToString()
                                })
                                );
            return View(applicationUsers);
        }

        public async Task<IActionResult> CStatus(string id)
        {
            //var data = await _userManager.FindByEmailAsync

            return RedirectToAction("Dashboard");
        }

        public async Task<IActionResult> SignUp()
        {          
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> SignUp(DealerVM obj)
        {           
            try
            {
                if (ModelState.IsValid)
                {
                    ApplicationUser applicationUser = new ApplicationUser()
                    {
                        UserName = obj.UserName,
                        Name = obj.Name,
                        Email = obj.Email,
                        PhoneNumber = obj.PhoneNumber,
                        City = obj.City,
                        State = obj.State,
                        StreetAddress = obj.StreetAddress,
                        PostalCode = obj.PostalCode.ToString(),
                        loginStatus= LoginStatus.Pending                       

                    };

                    await _userManager.CreateAsync(applicationUser, obj.Password);

                    if (_roleManager.RoleExistsAsync("Dealer").GetAwaiter().GetResult())
                    {
                        IdentityResult result = await _userManager.AddToRoleAsync(applicationUser, "Dealer");
                    }

                    return RedirectToAction("Index");
                }
                   
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return View();
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}